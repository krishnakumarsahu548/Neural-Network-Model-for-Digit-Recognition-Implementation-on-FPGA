`timescale 1ns / 1ps
`include "include.svh"

module nn_top_fpga_tb;

    reg clock_p, clock_n;
    reg reset_btn, start_btn;

    wire [3:0] led;

    // ------------------------------------------------------------------------
    // ---> UPDATE KIYA: 100 Expected labels ki array <---
    // Apni 'expected_labels.txt' file se 100 comma-separated numbers yahan paste karein:
    // ------------------------------------------------------------------------
    int expected_labels [0:99] = '{
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
         2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
          3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
           4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
            5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
             6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
              7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
               8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
                9, 9, 9, 9, 9, 9, 9, 9, 9, 9 
        // Example: 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1 ... (Total 100)
    };

    // Loop variables aur Accuracy Counter
    integer i;
    integer correct_predictions;

    // DUT (Device Under Test)
    nn_top_fpga uut (
        .clock_p(clock_p),
        .clock_n(clock_n),
        .reset_btn(reset_btn),
        .start_btn(start_btn),
        .led(led)
    );

    // ---------------- CLOCK GENERATION (100 MHz) ----------------
    initial begin
        clock_p = 0;
        clock_n = 1;
    end

    always #5 begin   
        clock_p = ~clock_p;
        clock_n = ~clock_n;
    end

    // ---------------- MAIN TEST SEQUENCE ----------------
    initial begin
        $display("===========================================");
        $display("      NN FPGA 100-IMAGE ACCURACY TEST      ");
        $display("===========================================");

        // Initial setup
        reset_btn = 1;
        start_btn = 1;
        correct_predictions = 0;

        // -------- RESET SEQUENCE --------
        #20;
        reset_btn = 1;   // press reset 
        #50;
        reset_btn = 0;   // release reset

        // BRAM ko settle hone ke liye thoda time dein
        #200;

        // -------- 100 IMAGES AUTOMATED TESTING LOOP --------
        for (i = 0; i < 100; i = i + 1) begin
            
            // -------- START PULSE --------
            start_btn = 0;   // Press Start
            #40;             
            start_btn = 1;   // Release Start

            // -------- WAIT FOR NEURAL NET TO FINISH --------
            // FSM jab calculation puri karke 'label_ready_net' high karega, tab aage badhenge
            wait (uut.label_ready_net == 1);

            // Output latch hone ke liye thoda margin
            #20;

            // -------- VERIFY RESULT --------
            if (led == expected_labels[i]) begin
                $display("[%02d/100] PASS: Predicted = %0d | Expected = %0d", i+1, led, expected_labels[i]);
                correct_predictions = correct_predictions + 1;
            end else begin
                $display("[%02d/100] FAIL: Predicted = %0d | Expected = %0d  <-- ERROR", i+1, led, expected_labels[i]);
            end

            // Agli image start karne se pehle FSM ko aaram karne ke liye time dein
            #500;
        end

        // -------- FINAL ACCURACY REPORT --------
        $display("===========================================");
        $display("             TEST COMPLETE!                ");
        $display(" FINAL ACCURACY: %0d / 100 (%0d %%)", correct_predictions, correct_predictions);
        $display("===========================================");

        #1000;
        $finish; // Stop simulation
    end

    // ---------------- DEBUG MONITOR ----------------
    initial begin
        // Ye console mein sirf tab print karega jab start pulse aaye ya result aaye
        // Taaki console me bohot zyada kachra na bhare
        // Aap chahein toh isko comment bhi kar sakte hain
    end

endmodule