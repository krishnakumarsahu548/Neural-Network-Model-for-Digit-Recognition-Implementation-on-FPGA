`timescale 1ns / 1ps
`ifndef INCLUDE_SVH
`define INCLUDE_SVH

// --------------------
// Fixed-point format
// --------------------
// Use Q8.8 by default (change if you want a different Q format)
parameter int INTEGRAL_WIDTH = 8;    // signed integer bits
parameter int FRACTION_WIDTH = 8;    // fractional bits
parameter int FIXED_POINT_WIDTH = INTEGRAL_WIDTH + FRACTION_WIDTH; // 16 by default
 
// sizes (network)
parameter int INPUT_SIZE = 784; // MNIST
parameter int L1_SIZE    = 16;
parameter int L2_SIZE    = 16;
parameter int OUTPUT_SIZE= 10;

// --------------------
// fixed_point struct (packed)
// --------------------
// integral is signed, fraction is unsigned.
// packed so we can cast/concatenate easily.
typedef enum logic [2:0] { NONE ,RELU, SOFTMAX} activation_type;

typedef struct packed {
    logic signed [INTEGRAL_WIDTH-1:0] integral;
    logic        [FRACTION_WIDTH-1:0] fraction;
} fixed_point;


typedef struct {
    int         id;         // can be used to store input-size constant or an index
    int         SIZE;       // number of neurons (e.g., 784, 16, 10)
    activation_type ACTIVATION; // RELU / SOFTMAX / NONE
} layer_builder;
typedef enum logic [3:0] {INPUTlayer , hidden1, hidden2 , outputlayer} layer_type;

// --------------------
// Utility conversions
// --------------------
// Convert fixed_point struct -> signed vector (FIXED_POINT_WIDTH bits)
// The mapping is: {integral[F...], fraction[F...]} (two's complement preserved)
function automatic logic signed [FIXED_POINT_WIDTH-1:0] fixed_to_signed;
    input fixed_point fp;
    begin
        // Concatenate: integral (signed) is MSB part, fraction is LSB part
        fixed_to_signed = { fp.integral, fp.fraction };
    end
endfunction

// Convert signed vector -> fixed_point struct
function automatic fixed_point signed_to_fixed;
    input logic signed [FIXED_POINT_WIDTH-1:0] s;
    begin
        signed_to_fixed.integral = s[FIXED_POINT_WIDTH-1:FRACTION_WIDTH];
        signed_to_fixed.fraction = s[FRACTION_WIDTH-1:0];
    end
endfunction

// Helper: convert 16-bit BRAM word (logic[15:0]) to signed vector
// If your BRAM data is exactly 16-bit Q8.8 packed as [15:8]=integral (signed), [7:0]=fraction
// you can use this to interpret BRAM data directly as signed 16-bit vector.
function automatic logic signed [FIXED_POINT_WIDTH-1:0] bramword_to_signed;
    input logic [FIXED_POINT_WIDTH-1:0] w; // e.g., w = bram_dout (16-bit)
    begin
        // reinterpret bits as signed vector (no bit permutation)
        bramword_to_signed = logic'(w);
    end
endfunction

// Helper: produce fixed_point from 16-bit BRAM word quickly
function automatic fixed_point bramword_to_fixed;
    input logic [FIXED_POINT_WIDTH-1:0] w;
    begin
        bramword_to_fixed.integral = w[FIXED_POINT_WIDTH-1:FRACTION_WIDTH];
        bramword_to_fixed.fraction = w[FRACTION_WIDTH-1:0];
    end
endfunction

// --------------------
// Small arithmetic helpers
// --------------------

// Multiply two Q(INTEGRAL,FRACTION) numbers (FIXED_POINT_WIDTH each).
// Returns signed [2*FIXED_POINT_WIDTH-1:0] product which is effectively Q(2*INTEGRAL, 2*FRACTION).
function automatic logic signed [(2*FIXED_POINT_WIDTH)-1:0] fixed_mult;
    input logic signed [FIXED_POINT_WIDTH-1:0] a;
    input logic signed [FIXED_POINT_WIDTH-1:0] b;
    logic signed [(2*FIXED_POINT_WIDTH)-1:0] prod;
    begin
        prod = a * b;
        fixed_mult = prod;
    end
endfunction

// Normalize product-sum accumulator (which is in Q(2*FRACTION)) back to Q(FRACTION)
// We assume accumulator is sufficiently wide (user must ensure)
// This does arithmetic right shift by FRACTION_WIDTH (i.e., >>> FRACTION_WIDTH)
function automatic logic signed [FIXED_POINT_WIDTH-1:0] acc_to_fixed;
    input logic signed [(2*FIXED_POINT_WIDTH)+31:0] acc; // wide accumulator (user may declare exact width)
    begin
        acc_to_fixed = acc >>> FRACTION_WIDTH;
    end
endfunction

// --------------------
// Safe cast helpers for synthesis-friendly code
// --------------------
// Casting macros / small functions make code more readable and less error-prone.

// Convert fixed_point struct to a vector literal for concatenation/assignment
function automatic logic [FIXED_POINT_WIDTH-1:0] fixed_to_vector;
    input fixed_point fp;
    begin
        fixed_to_vector = {fp.integral, fp.fraction};
    end
endfunction

// Convert vector to fixed_point struct (alias for signed_to_fixed but accepts unsigned too)
function automatic fixed_point vector_to_fixed;
    input logic [FIXED_POINT_WIDTH-1:0] v;
    begin
        vector_to_fixed.integral = v[FIXED_POINT_WIDTH-1:FRACTION_WIDTH];
        vector_to_fixed.fraction = v[FRACTION_WIDTH-1:0];
    end
endfunction

`endif
///


