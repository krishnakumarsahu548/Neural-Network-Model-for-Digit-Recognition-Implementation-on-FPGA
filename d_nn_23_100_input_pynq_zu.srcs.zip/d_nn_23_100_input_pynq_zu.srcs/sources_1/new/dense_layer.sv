`timescale 1ns / 1ps
`include "include.svh"

module dense_layer #(
    parameter int NUM_INPUTS  = 784,     // number of inputs
    parameter int NUM_NEURONS = 16,      // number of neurons in this layer
    parameter activation_type ACTIVATION = RELU
)(
    input  logic clock,
    input  logic reset,

    input  logic inputs_ready,                        // start when inputs valid
    input  fixed_point inputs   [NUM_INPUTS],         // array of inputs
    input  fixed_point weights  [NUM_NEURONS][NUM_INPUTS], // weights for each neuron
    input  fixed_point biases   [NUM_NEURONS],        // biases
    output fixed_point outputs  [NUM_NEURONS],        // outputs from all neurons
    output logic outputs_ready                        // high when all done
);

    // Internal: each neuron asserts a ready flag when done
    wire [NUM_NEURONS-1:0] neuron_ready_signals;

    // Generate neurons in parallel
    genvar i;
    generate
        for (i = 0; i < NUM_NEURONS; i++) begin : neuron_instance_block
            neuron #(
                .NUM_INPUTS(NUM_INPUTS),
                .ACTIVATION(ACTIVATION)
            ) inst_neuron (
                .clock(clock),
                .reset(reset),
                .input_ready(inputs_ready),
                .inputs(inputs),
                .weights(weights[i]),
                .bias(biases[i]),
                .output_value(outputs[i]),
                .output_ready(neuron_ready_signals[i])
            );
        end
    endgenerate

    // outputs_ready: registered "all neurons ready" signal
    always_ff @(posedge clock or posedge reset) begin
        if (reset) begin
            outputs_ready <= 1'b0;
        end else begin
            outputs_ready <= &neuron_ready_signals; // AND-reduction
        end
    end

endmodule
