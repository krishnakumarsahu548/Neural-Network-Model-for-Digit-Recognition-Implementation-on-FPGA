`timescale 1ns / 1ps
`include "include.svh"

module nn_top_fpga (
    input  wire clock_p,        // differential clock pins
    input  wire clock_n,
    input  wire reset_btn,      // on-board button (active-low with pullup)
    input  wire start_btn,      // on-board button (active-low with pullup)
    output wire [3:0] led
);

    // ---------- differential clock buffer ----------
    wire clock;
    IBUFDS ibufds_clk_inst (
        .I (clock_p),
        .IB(clock_n),
        .O (clock)
    );

    // ----------------- button synchronizers -----------------
    logic reset_sync1, reset_sync2;
    always_ff @(posedge clock) begin
        reset_sync1 <= reset_btn;
        reset_sync2 <= reset_sync1;
    end

    logic start_sync1, start_sync2;
    always_ff @(posedge clock) begin
        start_sync1 <= start_btn;
        start_sync2 <= start_sync1;
    end

    wire reset_btn_active = reset_sync2;   // active-high reset inside design
    wire start_btn_active = start_sync2;   // active-high when pressed (level)

    logic start_prev;
    always_ff @(posedge clock) begin
        start_prev <= start_btn_active;
    end
    wire start_pulse = start_btn_active & ~start_prev;
    wire reset_clean = reset_btn_active;

    // ------------------------------------------------------------------------
    // BRAM address/data lines 
    // ------------------------------------------------------------------------
    logic [13:0] w1_addr; logic signed [15:0] w1_data;
    logic [3:0]  b1_addr; logic signed [15:0] b1_data;
    logic [7:0]  w2_addr; logic signed [15:0] w2_data;
    logic [3:0]  b2_addr; logic signed [15:0] b2_data;
    logic [7:0]  w3_addr; logic signed [15:0] w3_data;
    logic [3:0]  b3_addr; logic signed [15:0] b3_data;
    logic [9:0]  px_addr; // NN se aane wala 0-783 address

    // ------------------------------------------------------------------------
    // ---> NAYA ADD KIYA: 100 Images Address Logic <---
    // ------------------------------------------------------------------------
    logic [6:0] image_counter;        // 0 se 99 tak count karne ke liye 7-bits chahiye
    logic [16:0] real_bram_addr;      // 78400 tak address ke liye 17-bits chahiye
    logic signed [15:0] px_data_100;  // BRAM se aane wala data

    // Magic Formula: (Current Image * 784) + px_addr
    assign real_bram_addr = (image_counter * 784) + px_addr;

    // ------------------------------------------------------------------------
    // Weights and Bias BRAM IP instances
    // ------------------------------------------------------------------------
    blk_mem_gen_0_w1            u_w1 (.clka(clock), .ena(1'b1), .addra(w1_addr), .douta(w1_data));
    blk_mem_gen_0_b1            u_b1 (.clka(clock), .ena(1'b1), .addra(b1_addr), .douta(b1_data));
    blk_mem_gen_0_w2            u_w2 (.clka(clock), .ena(1'b1), .addra(w2_addr), .douta(w2_data));
    blk_mem_gen_0_b2            u_b2 (.clka(clock), .ena(1'b1), .addra(b2_addr), .douta(b2_data));
    blk_mem_gen_0_w3            u_w3 (.clka(clock), .ena(1'b1), .addra(w3_addr), .douta(w3_data));
    blk_mem_gen_0_b3            u_b3 (.clka(clock), .ena(1'b1), .addra(b3_addr), .douta(b3_data));

    // ------------------------------------------------------------------------
    // ---> NAYA ADD KIYA: Single Large BRAM Instance (100 Images) <---
    // Note: IP name must match Step 2 ('blk_mem_gen_100_images')
    // ------------------------------------------------------------------------
    blk_mem_gen_0_100_images  u_px_100 (
        .clka(clock), 
        .ena(1'b1), 
        .addra(real_bram_addr),  // Naya 17-bit address diya
        .douta(px_data_100)      // Output data liya
    );

    // ------------------------------------------------------------------------
    // regnet streaming instance 
    // ------------------------------------------------------------------------
    logic [3:0] label_net;
    logic       label_ready_net;

    // Debug signals
    logic signed [47:0] debug_accumulator;
    logic [4:0]         debug_state;
    logic [7:0]         debug_n_neuron;
    logic [10:0]        debug_n_input;
    logic [13:0]        debug_w1_addr_out;
    logic [9:0]         debug_px_addr_out;
    logic [15:0]        debug_w1_dout;
    logic [15:0]        debug_px_dout;
    logic [15:0]        debug_bias_dout;
    logic [15:0]        debug_layer3_out [0:OUTPUT_SIZE-1];

    regnet_fpga_streaming #(
        .INPUT_SIZE(INPUT_SIZE),
        .L1_SIZE(L1_SIZE),
        .L2_SIZE(L2_SIZE),
        .OUTPUT_SIZE(OUTPUT_SIZE)
    ) rp_stream (
        .clk         (clock),
        .reset       (reset_clean),
        .start_load  (start_pulse),

        // BRAM data inputs
        .w1_data     (w1_data),
        .b1_data     (b1_data),
        .w2_data     (w2_data),
        .b2_data     (b2_data),
        .w3_data     (w3_data),
        .b3_data     (b3_data),
        .px_data     (px_data_100), // ---> Naye BRAM ka data connect kiya <---

        // BRAM address outputs
        .w1_addr     (w1_addr),
        .b1_addr     (b1_addr),
        .w2_addr     (w2_addr),
        .b2_addr     (b2_addr),
        .w3_addr     (w3_addr),
        .b3_addr     (b3_addr),
        .px_addr     (px_addr),

        // outputs
        .label       (label_net),
        .label_ready (label_ready_net),

        // debug probes
        .debug_accumulator (debug_accumulator),
        .debug_state       (debug_state),
        .debug_n_neuron    (debug_n_neuron),
        .debug_n_input     (debug_n_input),
        .debug_w1_addr_out (debug_w1_addr_out),
        .debug_px_addr_out (debug_px_addr_out),
        .debug_w1_dout     (debug_w1_dout),
        .debug_px_dout     (debug_px_dout),
        .debug_bias_dout   (debug_bias_dout),
        .debug_layer3_out  (debug_layer3_out)
    );

    // ------------------------------------------------------------------------
    // ---> NAYA ADD KIYA: 100 Images Counter <---
    // ------------------------------------------------------------------------
    logic label_ready_q;
    logic [3:0] label_latched;
    always_ff @(posedge clock) begin
        if (reset_clean) begin
            label_ready_q <= 1'b0;
            label_latched <= 4'd0;
            image_counter <= 7'd0; // Reset par image 0 se shuru hoga
        end else begin
            label_ready_q <= label_ready_net;
            
            // Jab ek image ki calculation puri ho jaye (Rising edge)
            if (!label_ready_q && label_ready_net) begin
                label_latched <= label_net;
                
                // Counter ko 0 se 99 tak chalayein
                if (image_counter == 7'd99)
                    image_counter <= 7'd0;
                else
                    image_counter <= image_counter + 1;
            end
        end
    end

    assign led = label_latched;

// ------------------------------------------------------------------
// ILA instantiation 
// ------------------------------------------------------------------
ila_0 ila_inst (
    .clk      (clock),

    .probe0   (start_pulse),           
    .probe1   (debug_state),           
    .probe2   (debug_px_addr_out),     
    .probe3   (debug_px_dout),         
    .probe4   (debug_w1_addr_out),     
    .probe5   (debug_w1_dout),         
    .probe6   (debug_n_input),         
    .probe7   (label_ready_net),       
    .probe8   (label_net) ,            
    .probe9   (debug_layer3_out[0]), 
    .probe10  (debug_layer3_out[1]), 
    .probe11  (debug_layer3_out[2]), 
    .probe12  (debug_layer3_out[3]), 
    .probe13  (debug_layer3_out[4]), 
    .probe14  (debug_layer3_out[5]), 
    .probe15  (debug_layer3_out[6]), 
    .probe16  (debug_layer3_out[7]), 
    .probe17  (debug_layer3_out[8]), 
    .probe18  (debug_layer3_out[9]), 
    .probe19  (image_counter)         // ---> UPDATE KIYA: Ab ye 7-bit ka counter hai (0-99)
);

endmodule