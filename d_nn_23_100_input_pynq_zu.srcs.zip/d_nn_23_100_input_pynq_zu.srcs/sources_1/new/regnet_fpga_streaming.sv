`timescale 1ns / 1ps
`include "include.svh"

module regnet_fpga_streaming #(
    parameter int INPUT_SIZE  = INPUT_SIZE,   // from include.svh
    parameter int L1_SIZE     = L1_SIZE,
    parameter int L2_SIZE     = L2_SIZE,
    parameter int OUTPUT_SIZE = OUTPUT_SIZE
)(
    input  logic        clk,
    input  logic        reset,       // active-high sync reset
    input  logic        start_load,  // one-cycle pulse to start sequence

    // BRAM data inputs (16-bit Q8.8)
    input  logic [15:0] w1_data,
    input  logic [15:0] b1_data,
    input  logic [15:0] w2_data,
    input  logic [15:0] b2_data,
    input  logic [15:0] w3_data,
    input  logic [15:0] b3_data,
    input  logic [15:0] px_data,

    // BRAM address outputs (driven by this module) - all driven sequentially
    output logic [13:0] w1_addr, // enough for 12544 entries
    output logic [3:0]  b1_addr,
    output logic [7:0]  w2_addr,
    output logic [3:0]  b2_addr,
    output logic [7:0]  w3_addr,
    output logic [3:0]  b3_addr,
    output logic [9:0]  px_addr, // 0..783

    // final outputs
    output logic [3:0]  label,
    output logic        label_ready,

    // -------------------- debug outputs for ILA --------------------
    // these are registered outputs that mirror internal signals for probe
    output logic signed [47:0] debug_accumulator, // full accumulator (48b)
    output logic [4:0]         debug_state,       // FSM state (5 bits)
    output logic [7:0]         debug_n_neuron,    // neuron index
    output logic [10:0]        debug_n_input,     // input index (covers up to 2047)
    output logic [13:0]        debug_w1_addr_out, // report w1_addr (14 bits)
    output logic [9:0]         debug_px_addr_out, // report px_addr (10 bits)
    output logic [15:0]        debug_w1_dout,     // registered w1 bram dout
    output logic [15:0]        debug_px_dout,     // registered px bram dout
    output logic [15:0]        debug_bias_dout,    // registered bias bram dout (b1_data_d)
    
    output logic [15:0]        debug_layer3_out [0:OUTPUT_SIZE-1]
);

    // ------------------------------------------------------------
    // Local params and small reg arrays for layer outputs
    // ------------------------------------------------------------
    localparam int TOTAL_W1 = L1_SIZE * INPUT_SIZE;
    localparam int TOTAL_W2 = L2_SIZE * L1_SIZE;
    localparam int TOTAL_W3 = OUTPUT_SIZE * L2_SIZE;

    // small outputs stored as fixed_point structs
    fixed_point layer1_out [0:L1_SIZE-1];
    fixed_point layer2_out [0:L2_SIZE-1];
    fixed_point layer3_out [0:OUTPUT_SIZE-1];

    // ------------------------------------------------------------
    // Registered BRAM outputs (capture synchronous BRAM dout)
    // ------------------------------------------------------------
    logic [15:0] w1_data_d, b1_data_d, w2_data_d, b2_data_d, w3_data_d, b3_data_d, px_data_d;

    // ------------------------------------------------------------
    // FSM states ---> ADDED WAIT2 STATES HERE
    // ------------------------------------------------------------
    typedef enum logic [4:0] {
        S_IDLE,
        
        S_LAYER1_NEURON_ADDR, S_LAYER1_WAIT, S_LAYER1_WAIT2, S_LAYER1_NEURON_ACC,
        S_LAYER1_BIAS_WAIT, S_LAYER1_BIAS_WAIT2, S_LAYER1_BIAS_READ,
        
        S_LAYER2_NEURON_ADDR, S_LAYER2_WAIT, S_LAYER2_WAIT2, S_LAYER2_NEURON_ACC,
        S_LAYER2_BIAS_WAIT, S_LAYER2_BIAS_WAIT2, S_LAYER2_BIAS_READ,
        
        S_LAYER3_NEURON_ADDR, S_LAYER3_WAIT, S_LAYER3_WAIT2, S_LAYER3_NEURON_ACC,
        S_LAYER3_BIAS_WAIT, S_LAYER3_BIAS_WAIT2, S_LAYER3_BIAS_READ,
        
        S_DONE
    } state_t;

    state_t state, next_state;

    // indices / counters (synthesizable integers)
    integer n_neuron;    // current neuron index
    integer n_input;     // current input index for MAC loop

    // MAC accumulator and temporaries
    logic signed [47:0] accumulator;
    logic signed [15:0] op_a, op_b;
    logic signed [31:0] product;

    // temps for bias and output
    logic signed [47:0] bias_ext;
    logic signed [47:0] biased_acc;
    logic signed [15:0] out_q;

    // output regs
    logic [3:0] label_reg;
    logic label_ready_reg;

// ------------------------------------------------------------
// Direct BRAM data assignment (No extra clock delay)
// ------------------------------------------------------------
assign w1_data_d = w1_data;
assign b1_data_d = b1_data;
assign w2_data_d = w2_data;
assign b2_data_d = b2_data;
assign w3_data_d = w3_data;
assign b3_data_d = b3_data;
assign px_data_d = px_data;

    // ------------------------------------------------------------
    // State register
    // ------------------------------------------------------------
    always_ff @(posedge clk or posedge reset) begin
        if (reset) state <= S_IDLE;
        else state <= next_state;
    end

    // ------------------------------------------------------------
    // Next-state logic (combinational) ---> UPDATED FOR WAIT2
    // ------------------------------------------------------------
 always_comb begin
    next_state = state;

    case (state)

        S_IDLE:
            if (start_load) next_state = S_LAYER1_NEURON_ADDR;

        // -------- LAYER 1 --------
        S_LAYER1_NEURON_ADDR: next_state = S_LAYER1_WAIT;
        S_LAYER1_WAIT:        next_state = S_LAYER1_WAIT2;
        S_LAYER1_WAIT2:       next_state = S_LAYER1_NEURON_ACC;

        S_LAYER1_NEURON_ACC:
            if (n_input == INPUT_SIZE - 1)
                next_state = S_LAYER1_BIAS_WAIT;
            else
                next_state = S_LAYER1_NEURON_ADDR;

        S_LAYER1_BIAS_WAIT:  next_state = S_LAYER1_BIAS_WAIT2;
        S_LAYER1_BIAS_WAIT2: next_state = S_LAYER1_BIAS_READ;

        S_LAYER1_BIAS_READ:
            if (n_neuron < L1_SIZE - 1)
                next_state = S_LAYER1_NEURON_ADDR;
            else
                next_state = S_LAYER2_NEURON_ADDR;

        // -------- LAYER 2 --------
        S_LAYER2_NEURON_ADDR: next_state = S_LAYER2_WAIT;
        S_LAYER2_WAIT:        next_state = S_LAYER2_WAIT2;
        S_LAYER2_WAIT2:       next_state = S_LAYER2_NEURON_ACC;

        S_LAYER2_NEURON_ACC:
            if (n_input == L1_SIZE - 1)
                next_state = S_LAYER2_BIAS_WAIT;
            else
                next_state = S_LAYER2_NEURON_ADDR;

        S_LAYER2_BIAS_WAIT:  next_state = S_LAYER2_BIAS_WAIT2;
        S_LAYER2_BIAS_WAIT2: next_state = S_LAYER2_BIAS_READ;

        S_LAYER2_BIAS_READ:
            if (n_neuron < L2_SIZE - 1)
                next_state = S_LAYER2_NEURON_ADDR;
            else
                next_state = S_LAYER3_NEURON_ADDR;

        // -------- LAYER 3 --------
        S_LAYER3_NEURON_ADDR: next_state = S_LAYER3_WAIT;
        S_LAYER3_WAIT:        next_state = S_LAYER3_WAIT2;
        S_LAYER3_WAIT2:       next_state = S_LAYER3_NEURON_ACC;

        // MAC loop
        S_LAYER3_NEURON_ACC:
            if (n_input == L2_SIZE - 1)
                next_state = S_LAYER3_BIAS_WAIT;   
            else
                next_state = S_LAYER3_NEURON_ADDR;

        // bias pipeline
        S_LAYER3_BIAS_WAIT:  next_state = S_LAYER3_BIAS_WAIT2;
        S_LAYER3_BIAS_WAIT2: next_state = S_LAYER3_BIAS_READ;

        S_LAYER3_BIAS_READ:
            if (n_neuron < OUTPUT_SIZE - 1)
                next_state = S_LAYER3_NEURON_ADDR;   // next neuron
            else
                next_state = S_DONE;                 // finish
                
        // -------- DONE --------
        S_DONE: next_state = S_IDLE; // Automatically return to IDLE for next image

        default: next_state = S_IDLE;

    endcase
end

    // ------------------------------------------------------------
    // Main sequential FSM: addresses, MACs, writes to small regs
    // All BRAM address outputs driven only here (single-driver)
    // Also update debug outputs here (single always_ff)
    // ------------------------------------------------------------
    always_ff @(posedge clk or posedge reset) begin
        if (reset) begin
            // counters / accumulators
            n_neuron <= 0;
            n_input  <= 0;
            accumulator <= '0;

            // label outputs
            label_reg <= 4'd0;
            label_ready_reg <= 1'b0;

            // initialize BRAM address outputs to safe values (single-driver)
            w1_addr <= 14'd0;
            b1_addr <= 4'd0;
            w2_addr <= 8'd0;
            b2_addr <= 4'd0;
            w3_addr <= 8'd0;
            b3_addr <= 4'd0;
            px_addr <= 10'd0;

            // clear layer outputs
            for (int i=0; i < L1_SIZE; i++) begin
                layer1_out[i].integral <= '0;
                layer1_out[i].fraction <= '0;
            end
            for (int i=0; i < L2_SIZE; i++) begin
                layer2_out[i].integral <= '0;
                layer2_out[i].fraction <= '0;
            end
            for (int i=0; i < OUTPUT_SIZE; i++) begin
                layer3_out[i].integral <= '0;
                layer3_out[i].fraction <= '0;
            end

            // clear debug outputs
            debug_accumulator <= '0;
            debug_state       <= '0;
            debug_n_neuron    <= '0;
            debug_n_input     <= '0;
            debug_w1_addr_out <= '0;
            debug_px_addr_out <= '0;
            debug_w1_dout     <= 16'd0;
            debug_px_dout     <= 16'd0;
            debug_bias_dout   <= 16'd0;
            for (int i = 0; i < OUTPUT_SIZE; i++) begin
                debug_layer3_out[i] <= 16'd0;
            end

        end else begin
            // default: clear label_ready each cycle; state actions set it when done
            label_ready_reg <= 1'b0;

        case (state)

    S_IDLE: begin
        n_neuron <= 0;
        n_input  <= 0;
        accumulator <= '0;
    end

    // ---------------- LAYER 1 ----------------
    S_LAYER1_NEURON_ADDR: begin
        w1_addr <= (n_neuron * INPUT_SIZE) + n_input;
        px_addr <= n_input;
    end

    // WAIT2 Added here
    S_LAYER1_WAIT, S_LAYER1_WAIT2: begin end

    S_LAYER1_NEURON_ACC: begin
        op_a = fixed_to_signed(bramword_to_fixed(px_data_d));
        op_b = fixed_to_signed(bramword_to_fixed(w1_data_d));
        product = op_a * op_b;
        accumulator <= accumulator + product;

        if (n_input == INPUT_SIZE - 1)
            n_input <= 0;
        else
            n_input <= n_input + 1;
    end

    // Hold address for both wait cycles
    S_LAYER1_BIAS_WAIT, S_LAYER1_BIAS_WAIT2: begin
        b1_addr <= n_neuron;
    end

    S_LAYER1_BIAS_READ: begin
        bias_ext = fixed_to_signed(bramword_to_fixed(b1_data_d));
        bias_ext = bias_ext <<< FRACTION_WIDTH;
        biased_acc = accumulator + bias_ext;
        out_q = biased_acc >>> FRACTION_WIDTH;

        if (out_q < 0) out_q = 16'sd0;

        layer1_out[n_neuron].integral <= out_q[15:8];
        layer1_out[n_neuron].fraction <= out_q[7:0];

        accumulator <= '0;
        n_input <= 0;

        if (n_neuron < L1_SIZE - 1)
            n_neuron <= n_neuron + 1;
        else begin
            n_neuron <= 0;
            n_input  <= 0;
        end
    end

    // ---------------- LAYER 2 ----------------
    S_LAYER2_NEURON_ADDR: begin
        w2_addr <= (n_neuron * L1_SIZE) + n_input;
    end

    // WAIT2 Added here
    S_LAYER2_WAIT, S_LAYER2_WAIT2: begin end

    S_LAYER2_NEURON_ACC: begin
        op_a = $signed(fixed_to_vector(layer1_out[n_input]));
        op_b = fixed_to_signed(bramword_to_fixed(w2_data_d));
        product = op_a * op_b;
        accumulator <= accumulator + product;

        if (n_input == L1_SIZE - 1)
            n_input <= 0;
        else
            n_input <= n_input + 1;
    end

    // Hold address for both wait cycles
    S_LAYER2_BIAS_WAIT, S_LAYER2_BIAS_WAIT2: begin
        b2_addr <= n_neuron;
    end

    S_LAYER2_BIAS_READ: begin
        bias_ext = fixed_to_signed(bramword_to_fixed(b2_data_d));
        bias_ext = bias_ext <<< FRACTION_WIDTH;
        biased_acc = accumulator + bias_ext;
        out_q = biased_acc >>> FRACTION_WIDTH;

        if (out_q < 0) out_q = 16'sd0;

        layer2_out[n_neuron].integral <= out_q[15:8];
        layer2_out[n_neuron].fraction <= out_q[7:0];

        accumulator <= '0;
        n_input <= 0;

        if (n_neuron < L2_SIZE - 1)
            n_neuron <= n_neuron + 1;
        else begin
            n_neuron <= 0;
            n_input  <= 0;
        end
    end

    // ---------------- LAYER 3 ----------------
    S_LAYER3_NEURON_ADDR: begin
        w3_addr <= (n_neuron * L2_SIZE) + n_input;
    end

    // WAIT2 Added here
    S_LAYER3_WAIT, S_LAYER3_WAIT2: begin end

    S_LAYER3_NEURON_ACC: begin
        op_a = $signed(fixed_to_vector(layer2_out[n_input]));
        op_b = fixed_to_signed(bramword_to_fixed(w3_data_d));
        product = op_a * op_b;
        accumulator <= accumulator + product;

        if (n_input == L2_SIZE - 1) 
            n_input <= 0;
        else
            n_input <= n_input + 1;
    end

    // Hold address for both wait cycles
    S_LAYER3_BIAS_WAIT, S_LAYER3_BIAS_WAIT2: begin
        b3_addr <= n_neuron; 
    end
    
    S_LAYER3_BIAS_READ: begin
        bias_ext = fixed_to_signed(bramword_to_fixed(b3_data_d));
        bias_ext = bias_ext <<< FRACTION_WIDTH;
        biased_acc = accumulator + bias_ext;
        out_q = biased_acc >>> FRACTION_WIDTH;
        
       // if (out_q < 0) out_q = 16'sd0;

        layer3_out[n_neuron].integral <= out_q[15:8];
        layer3_out[n_neuron].fraction <= out_q[7:0];

        accumulator <= '0;
        n_input <= 0;

        if (n_neuron < OUTPUT_SIZE - 1)
            n_neuron <= n_neuron + 1;
        else begin
            n_neuron <= 0;
            n_input  <= 0;
        end
    end

    // ---------------- DONE ----------------
    S_DONE: begin
        logic signed [15:0] max_val;
        int max_idx;

        max_idx = 0;
        max_val = fixed_to_signed(fixed_to_vector(layer3_out[0]));

        for (int i = 1; i < OUTPUT_SIZE; i++) begin
            logic signed [15:0] vv;
            vv = fixed_to_signed(fixed_to_vector(layer3_out[i]));
            if (vv > max_val) begin
                max_val = vv;
                max_idx = i;
            end
        end

        label_reg <= max_idx;
        label_ready_reg <= 1'b1;
    end

    default: ;

endcase

            // ------------------ debug outputs update (single-driver) ------------------
            // capture internal signals to debug outputs so ILA can probe them
            debug_accumulator <= accumulator;        // signed [47:0]
            debug_state       <= state;              // state_t [4:0]
            // n_neuron and n_input are integers; cast/limit into declared widths
            debug_n_neuron    <= n_neuron;           // truncated/extended to 8 bits
            debug_n_input     <= n_input;            // truncated/extended to 11 bits
            debug_w1_addr_out <= w1_addr;            // 14 bits
            debug_px_addr_out <= px_addr;            // 10 bits
            // capture the registered BRAM douts (these are available this cycle)
            debug_w1_dout     <= w1_data_d;
            debug_px_dout     <= px_data_d;
            debug_bias_dout   <= b1_data_d;
            // ---> NAYA ADD KIYA: Assign Layer 3 outputs to debug port <---
            // `fixed_to_vector` function use karke struct ko 16-bit logic me convert kiya
            for (int i = 0; i < OUTPUT_SIZE; i++) begin
                debug_layer3_out[i] <= fixed_to_vector(layer3_out[i]);
            end
        end
    end

    // outputs
    assign label = label_reg;
    assign label_ready = label_ready_reg;

endmodule