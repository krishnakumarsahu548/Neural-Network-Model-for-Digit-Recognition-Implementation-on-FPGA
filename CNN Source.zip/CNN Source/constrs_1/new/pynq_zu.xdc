# *****************************************************************************
# Modified XDC for PYNQ-ZU (Assuming 125MHz Differential Clock)
# *****************************************************************************

# --- CLOCK CONSTRAINTS ---
# Differential Clock Input (P/N pins)
set_property PACKAGE_PIN K3 [get_ports {clock_n}]
set_property IOSTANDARD LVDS [get_ports {clock_n}]
set_property PACKAGE_PIN K4 [get_ports {clock_p}]
set_property IOSTANDARD LVDS [get_ports {clock_p}]

# Primary clock constraint (8.000ns period for 125MHz)
#create_clock -name clk_125MHz -period 8 [get_ports {clock_p}]

# --- INPUT BUTTON CONSTRAINTS ---
# Reset Button #BTN0 
set_property PACKAGE_PIN AH14 [get_ports {rst_n}]   
set_property IOSTANDARD LVCMOS12 [get_ports {rst_n}]
#set_property PULLUP true [get_ports {reset_btn}]

# Start Button#BTN1
set_property PACKAGE_PIN AG14 [get_ports {start_btn}]    
set_property IOSTANDARD LVCMOS12 [get_ports {start_btn}]
#set_property PULLUP true [get_ports {start_btn}]


# --- LED OUTPUT CONSTRAINTS ---
# LED[0] to LED[3] #LED0 #LED1 #LED2 #LED3
set_property PACKAGE_PIN B5  [get_ports {led[0]}]    
set_property IOSTANDARD LVCMOS12 [get_ports {led[0]}]

set_property PACKAGE_PIN A6  [get_ports {led[1]}]    
set_property IOSTANDARD LVCMOS12 [get_ports {led[1]}]

set_property PACKAGE_PIN B8  [get_ports {led[2]}]    
set_property IOSTANDARD LVCMOS12 [get_ports {led[2]}]

set_property PACKAGE_PIN A7  [get_ports {led[3]}]    
set_property IOSTANDARD LVCMOS12 [get_ports {led[3]}]


