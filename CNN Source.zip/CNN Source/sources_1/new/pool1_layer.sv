`timescale 1ns / 1ps

module pool1_layer (
    input  logic               clk,
    input  logic               rst_n,
    input  logic               valid_in,       
    input  logic signed [15:0] pixel_in [0:5], 

    output logic signed [15:0] pixel_out [0:5], 
    output logic               valid_out        
);

    localparam IMG_WIDTH = 28;

    logic [4:0] col_count; 
    logic [4:0] row_count; 

    // Line Buffer for previous row
    logic signed [15:0] line_buffer [0:IMG_WIDTH-1][0:5];

    // FIX: Shift registers ko proper 2x2 state yaad rakhne ke liye design kiya gaya hai
    logic signed [15:0] window_2x2 [0:5][0:1][0:1]; 
    logic signed [15:0] max_pool_result [0:5];

    // Delay registers for forming the window
    logic signed [15:0] delay_pixel [0:5];       // Previous col in current row
    logic signed [15:0] delay_line_out [0:5];    // Previous col in previous row

    genvar i;
    generate
        for (i = 0; i < 6; i++) begin : max_pool_blocks
            // The 2x2 Window logic
            assign window_2x2[i][0][0] = delay_line_out[i];         // Top-Left
            assign window_2x2[i][0][1] = line_buffer[col_count][i]; // Top-Right (From Buffer)
            assign window_2x2[i][1][0] = delay_pixel[i];            // Bottom-Left
            assign window_2x2[i][1][1] = pixel_in[i];               // Bottom-Right (Current)

            max_pool_2x2 u_max_pool (
                .window(window_2x2[i]),
                .max_out(max_pool_result[i])
            );
        end
    endgenerate

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            col_count <= '0;
            row_count <= '0;
            valid_out <= 1'b0;
            
            for (int c = 0; c < IMG_WIDTH; c++) begin
                for (int ch = 0; ch < 6; ch++) line_buffer[c][ch] <= '0;
            end
            for (int ch = 0; ch < 6; ch++) begin
                delay_pixel[ch]    <= '0;
                delay_line_out[ch] <= '0;
                pixel_out[ch]      <= '0;
            end
        end
        else begin
            valid_out <= 1'b0; 

            if (valid_in) begin
                for (int ch = 0; ch < 6; ch++) begin
                    // Shift pixel for next cycle's left column
                    delay_pixel[ch]    <= pixel_in[ch];
                    delay_line_out[ch] <= line_buffer[col_count][ch];
                    
                    // Update line buffer with current pixel
                    line_buffer[col_count][ch] <= pixel_in[ch];
                end

                // 2x2 Output check
                if (row_count[0] == 1'b1 && col_count[0] == 1'b1) begin
                    valid_out <= 1'b1; 
                    for (int ch = 0; ch < 6; ch++) begin
                        pixel_out[ch] <= max_pool_result[ch]; 
                    end
                end

                if (col_count == IMG_WIDTH - 1) begin
                    col_count <= '0; 
                    if (row_count == IMG_WIDTH - 1) begin
                        row_count <= '0; 
                    end else begin
                        row_count <= row_count + 1; 
                    end
                end else begin
                    col_count <= col_count + 1; 
                end
            end
        end
    end
endmodule