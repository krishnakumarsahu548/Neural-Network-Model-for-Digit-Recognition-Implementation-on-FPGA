`timescale 1ns / 1ps

module conv2_layer (
    input  logic clk,
    input  logic rst_n,
    input  logic start_conv2,
    
    output logic [7:0]  pool1_bram_addr,
    input  logic [95:0] pool1_bram_dout,
    output logic [11:0] weight_bram_addr,
    input  logic signed [15:0] weight_bram_dout,
    output logic [3:0]  bias_bram_addr,
    input  logic signed [15:0] bias_bram_dout,
    
    output logic signed [15:0] conv2_out_pixel,
    output logic [3:0]         out_channel_idx,
    output logic               conv2_valid
);

    logic signed [15:0] all_weights [0:15][0:4][0:4][0:5]; 
    logic signed [15:0] all_biases  [0:15];

    typedef enum logic [2:0] {
        IDLE, LOAD_WEIGHTS, FETCH_PIXEL, WAIT_BRAM, COMPUTE_16_FILTERS, DONE
    } state_t;

    state_t current_state;

    logic [12:0] w_count;       
    logic [5:0]  b_count;       
    logic [8:0]  pixel_count;   
    logic [3:0]  filter_idx;    

    logic [3:0]  in_row; 
    logic [3:0]  in_col; 

    // ---> NAYA LOGIC: Hardware Safe Counters <---
    logic [3:0] w_f;  // 0 to 15
    logic [2:0] w_ch; // 0 to 5
    logic [2:0] w_r;  // 0 to 4
    logic [2:0] w_c;  // 0 to 4

    logic signed [15:0] pool1_pixel_array [0:5];
    assign pool1_pixel_array[0] = pool1_bram_dout[15:0];
    assign pool1_pixel_array[1] = pool1_bram_dout[31:16];
    assign pool1_pixel_array[2] = pool1_bram_dout[47:32];
    assign pool1_pixel_array[3] = pool1_bram_dout[63:48];
    assign pool1_pixel_array[4] = pool1_bram_dout[79:64];
    assign pool1_pixel_array[5] = pool1_bram_dout[95:80];

    logic signed [15:0] window_data [0:4][0:4][0:5];
    logic lb_valid_in;
    logic mac_valid_in;

    line_buffer_3d u_lb3d (.clk(clk), .rst_n(rst_n), .valid_in(lb_valid_in), .pixel_in(pool1_pixel_array), .window_3d(window_data));
    mac_engine_3d u_mac150 (.clk(clk), .rst_n(rst_n), .valid_in(mac_valid_in), .window_3d(window_data), .weights_3d(all_weights[filter_idx]), .bias(all_biases[filter_idx]), .out_pixel(conv2_out_pixel), .valid_out(conv2_valid));

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) out_channel_idx <= 0;
        else if (mac_valid_in) out_channel_idx <= filter_idx;
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_state <= IDLE;
            w_count <= 0; b_count <= 0; pixel_count <= 0; filter_idx <= 0;
            lb_valid_in <= 0; mac_valid_in <= 0;
            weight_bram_addr <= 0; bias_bram_addr <= 0; pool1_bram_addr <= 0;
            in_row <= 0; in_col <= 0; 
            w_f <= 0; w_ch <= 0; w_r <= 0; w_c <= 0;
            for(int i=0; i<16; i++) all_biases[i] <= 0;
        end else begin
            lb_valid_in <= 0;
            mac_valid_in <= 0;

            case (current_state)
                IDLE: begin
                    if (start_conv2) begin 
                        current_state <= LOAD_WEIGHTS;
                        w_count <= 0; b_count <= 0; pixel_count <= 0; filter_idx <= 0;
                        in_row <= 0; in_col <= 0;
                        w_f <= 0; w_ch <= 0; w_r <= 0; w_c <= 0; // Reset counters
                    end
                end

                LOAD_WEIGHTS: begin
                    if (w_count < 2400) weight_bram_addr <= w_count[11:0]; 
                    if (b_count < 16)   bias_bram_addr <= b_count[3:0];   

                    w_count <= w_count + 1;
                    b_count <= b_count + 1;

                    // NAYA LOGIC: Division hataya, perfectly 1 cycle delay pe save karega!
                    if (w_count >= 2 && w_count <= 2401) begin
                        all_weights[w_f][w_r][w_c][w_ch] <= weight_bram_dout;
                        
                        // Increment logic mimicking PyTorch order
                        if (w_c == 4) begin
                            w_c <= 0;
                            if (w_r == 4) begin
                                w_r <= 0;
                                if (w_ch == 5) begin
                                    w_ch <= 0;
                                    w_f <= w_f + 1;
                                end else w_ch <= w_ch + 1;
                            end else w_r <= w_r + 1;
                        end else w_c <= w_c + 1;
                    end
                    
                    if (b_count >= 2 && b_count <= 17) begin
                        all_biases[b_count - 2] <= bias_bram_dout;
                    end

                    if (w_count >= 2401) current_state <= FETCH_PIXEL;
                end

                FETCH_PIXEL: begin
                    if (pixel_count < 196) begin
                        pool1_bram_addr <= pixel_count[7:0];
                        pixel_count <= pixel_count + 1;
                        current_state <= WAIT_BRAM;
                    end else begin
                        current_state <= DONE;
                    end
                end

                WAIT_BRAM: begin
                    lb_valid_in <= 1'b1; 
                    if (in_row >= 4 && in_col >= 4) begin
                        current_state <= COMPUTE_16_FILTERS; 
                    end else begin
                        current_state <= FETCH_PIXEL; 
                    end

                    if (in_col == 4'd13) begin
                        in_col <= 0;
                        in_row <= in_row + 1;
                    end else begin
                        in_col <= in_col + 1;
                    end
                end

                COMPUTE_16_FILTERS: begin
                    mac_valid_in <= 1'b1; 
                    if (filter_idx == 15) begin
                        filter_idx <= 0;
                        current_state <= FETCH_PIXEL; 
                    end else begin
                        filter_idx <= filter_idx + 1; 
                    end
                end

                DONE: begin
                    current_state <= IDLE;
                end
            endcase
        end
    end
endmodule