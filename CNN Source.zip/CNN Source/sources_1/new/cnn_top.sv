`timescale 1ns / 1ps

module cnn_top #(
    parameter DEBOUNCE_LIMIT = 20'd1_000_000 // By default Hardware ke liye
)(
    input  wire clock_p,      
    input  wire clock_n,      
    input  wire rst_n,        
    input  wire start_btn,    
    output logic [3:0] led
);

    // =========================================================
    // 0. CLOCK CONVERSION (THE CLOCKING WIZARD FIX)
    // =========================================================
    wire clk; // 25MHz or 30MHz stable clock from MMCM
    
    clk_wiz_0 u_clock_wizard (
        .clk_in1_p (clock_p),
        .clk_in1_n (clock_n),
        .clk_out1  (clk)
    );

    // =========================================================
    // 1. ROBUST ANTI-BOUNCE (DEBOUNCER) & SYNCHRONIZER
    // =========================================================
    logic rst_sync1, rst_sync2;
    logic start_sync1, start_sync2;
    
    always_ff @(posedge clk) begin
        rst_sync1   <= rst_n;
        rst_sync2   <= rst_sync1;
        
        start_sync1 <= start_btn;
        start_sync2 <= start_sync1;
    end

    wire sys_rst_n = ~rst_sync2; 

    logic [19:0] debounce_counter;
    logic start_stable;
    logic start_prev;
    
    always_ff @(posedge clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            debounce_counter <= 0;
            start_stable     <= 0;
            start_prev       <= 0;
        end else begin
            if (start_sync2 == start_stable) begin
                debounce_counter <= 0;
            end else begin
                debounce_counter <= debounce_counter + 1;
                if (debounce_counter == DEBOUNCE_LIMIT) begin
                    start_stable <= start_sync2;
                end
            end
            start_prev <= start_stable;
        end
    end

    wire start_pulse = start_stable & ~start_prev;

    // =========================================================
    // 2. Wires & Internal Connections
    // =========================================================
    logic [9:0]  img_addr;  logic img_en;  logic signed [15:0] img_dout;
    logic [7:0]  c1_w_addr; logic c1_w_en; logic signed [15:0] c1_w_dout;
    logic [2:0]  c1_b_addr; logic c1_b_en; logic signed [15:0] c1_b_dout;
    logic signed [15:0] conv1_data_out [0:5]; logic conv1_valid_out;

    logic signed [15:0] pool1_data_out [0:5]; logic pool1_valid_out;
    logic [7:0]  pool1_bram_write_addr; logic [95:0] pool1_bram_write_data; logic pool1_done;

    logic [7:0]  c2_read_addr; logic [95:0] c2_read_data;
    logic [11:0] c2_w_addr; logic c2_w_en; logic signed [15:0] c2_w_dout;
    logic [3:0]  c2_b_addr; logic c2_b_en; logic signed [15:0] c2_b_dout;
    
    logic signed [15:0] final_conv2_out; logic [3:0] final_conv2_channel; logic final_conv2_valid;
    logic signed [15:0] pool2_data_out [0:15]; logic pool2_valid_out;

    logic [4:0]   pool2_bram_write_addr; logic [255:0] pool2_bram_write_data; logic pool2_done;
    
    logic [15:0] fc1_in_addr; logic [8:0] dense_read_addr; logic [15:0] dense_read_data;
    logic [15:0] fc1_w_addr; logic signed [15:0] fc1_w_dout;
    logic [15:0] fc1_b_addr; logic signed [15:0] fc1_b_dout;
    logic signed [15:0] fc1_out_data; logic [15:0] fc1_out_idx; logic fc1_out_valid; logic fc1_done;

    logic [15:0] fc2_in_addr; logic signed [15:0] fc2_in_data;
    logic [15:0] fc2_w_addr; logic signed [15:0] fc2_w_dout;
    logic [15:0] fc2_b_addr; logic signed [15:0] fc2_b_dout;
    logic signed [15:0] fc2_out_data; logic [15:0] fc2_out_idx; logic fc2_out_valid; logic fc2_done;

    logic [15:0] fc3_in_addr; logic signed [15:0] fc3_in_data;
    logic [15:0] fc3_w_addr; logic signed [15:0] fc3_w_dout;
    logic [15:0] fc3_b_addr; logic signed [15:0] fc3_b_dout;

    logic signed [15:0] fc1_to_fc2_buffer [0:15];
    logic signed [15:0] fc2_to_fc3_buffer [0:15];

    logic signed [15:0] final_fc3_out;
    logic [15:0]        final_fc3_idx;
    logic               final_fc3_valid;
    logic               cnn_done;

    logic pool1_done_prev, pool2_done_prev;
    logic fc1_done_prev, fc2_done_prev;
    
    always_ff @(posedge clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            pool1_done_prev <= 1'b0; pool2_done_prev <= 1'b0;
            fc1_done_prev   <= 1'b0; fc2_done_prev   <= 1'b0;
        end else begin
            pool1_done_prev <= pool1_done;
            pool2_done_prev <= pool2_done;
            fc1_done_prev   <= fc1_done;
            fc2_done_prev   <= fc2_done;
        end
    end

    wire conv2_start_pulse = pool1_done & ~pool1_done_prev;
    wire fc1_start_pulse   = pool2_done & ~pool2_done_prev;
    wire fc2_start_pulse   = fc1_done   & ~fc1_done_prev;
    wire fc3_start_pulse   = fc2_done   & ~fc2_done_prev;

    // =========================================================
    // 3. ROM & RAM Instantiations (100-IMAGE SINGLE BRAM)
    // =========================================================
    
    logic [6:0] image_idx; // 0 to 99 image index
    
    always_ff @(posedge clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            image_idx <= 7'd0; 
        end else if (cnn_done) begin
            if (image_idx == 7'd99) 
                image_idx <= 7'd0;
            else
                image_idx <= image_idx + 1;
        end
    end

    logic [16:0] real_bram_addr; // 17-bit for 102400 depth
    
    // THE 1024 MAGIC: 
    // Multiply by 1024 is shifting left by 10. 
    // {image_idx[6:0], img_addr[9:0]} forms the perfect 17-bit address! No Multiplier needed!
    assign real_bram_addr = {image_idx, img_addr}; 

    blk_mem_gen_0_100_images u_img_100_rom (
        .clka(clk), 
        .ena(1'b1), 
        .wea(1'b0), 
        .addra(real_bram_addr), 
        .dina(16'd0), 
        .douta(img_dout)        
    );

    // Weights and Biases
    blk_mem_gen_0_conv1_weight          u_c1_w_rom  (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(c1_w_addr), .dina(16'd0), .douta(c1_w_dout));
    blk_mem_gen_0_conv1_bias            u_c1_b_rom  (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(c1_b_addr), .dina(16'd0), .douta(c1_b_dout));
    blk_mem_gen_0_pool1_to_conv2_data   u_ping_pong (.clka(clk), .ena(1'b1), .wea(pool1_valid_out), .addra(pool1_bram_write_addr), .dina(pool1_bram_write_data), .clkb(clk), .enb(1'b1), .addrb(c2_read_addr), .doutb(c2_read_data));
    blk_mem_gen_0_conv2_weight          u_c2_w_rom  (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(c2_w_addr), .dina(16'd0), .douta(c2_w_dout));
    blk_mem_gen_0_conv2_bias            u_c2_b_rom  (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(c2_b_addr), .dina(16'd0), .douta(c2_b_dout));
    blk_mem_gen_0_pool2_flatten         u_flatten   (.clka(clk), .ena(1'b1), .wea(pool2_valid_out), .addra(pool2_bram_write_addr), .dina(pool2_bram_write_data), .clkb(clk), .enb(1'b1), .addrb(dense_read_addr), .doutb(dense_read_data));

    blk_mem_gen_0_fc1_w1 u_fc1_w_rom (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(fc1_w_addr[12:0]), .dina(16'd0), .douta(fc1_w_dout));
    blk_mem_gen_0_b1     u_fc1_b_rom (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(fc1_b_addr[3:0]),  .dina(16'd0), .douta(fc1_b_dout));
    blk_mem_gen_0_fc2_w2 u_fc2_w_rom (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(fc2_w_addr[7:0]),  .dina(16'd0), .douta(fc2_w_dout));
    blk_mem_gen_0_b2     u_fc2_b_rom (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(fc2_b_addr[3:0]),  .dina(16'd0), .douta(fc2_b_dout));
    blk_mem_gen_0_fc3_w3 u_fc3_w_rom (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(fc3_w_addr[7:0]),  .dina(16'd0), .douta(fc3_w_dout));
    blk_mem_gen_0_b3     u_fc3_b_rom (.clka(clk), .ena(1'b1), .wea(1'b0), .addra(fc3_b_addr[3:0]),  .dina(16'd0), .douta(fc3_b_dout));

    // =========================================================
    // 4. Hardware Layers
    // =========================================================
    conv1_layer u_conv1 (.clk(clk), .rst_n(sys_rst_n), .start_btn(start_pulse), .weight_addr(c1_w_addr), .weight_en(c1_w_en), .weight_dout(c1_w_dout), .bias_addr(c1_b_addr), .bias_en(c1_b_en), .bias_dout(c1_b_dout), .img_addr(img_addr), .img_en(img_en), .img_dout(img_dout), .conv_out(conv1_data_out), .conv_valid(conv1_valid_out), .layer_done());
    pool1_layer u_pool1 (.clk(clk), .rst_n(sys_rst_n), .valid_in(conv1_valid_out), .pixel_in(conv1_data_out), .pixel_out(pool1_data_out), .valid_out(pool1_valid_out));
    conv2_layer u_conv2 (.clk(clk), .rst_n(sys_rst_n), .start_conv2(conv2_start_pulse), .pool1_bram_addr(c2_read_addr), .pool1_bram_dout(c2_read_data), .weight_bram_addr(c2_w_addr), .weight_bram_dout(c2_w_dout), .bias_bram_addr(c2_b_addr), .bias_bram_dout(c2_b_dout), .conv2_out_pixel(final_conv2_out), .out_channel_idx(final_conv2_channel), .conv2_valid(final_conv2_valid));
    pool2_layer u_pool2 (.clk(clk), .rst_n(sys_rst_n), .conv2_pixel_in(final_conv2_out), .conv2_channel_idx(final_conv2_channel), .conv2_valid_in(final_conv2_valid), .pool2_out(pool2_data_out), .pool2_valid_out(pool2_valid_out));

    assign dense_read_addr = fc1_in_addr[8:0]; 
    dense_layer #(.IN_NEURONS(400), .OUT_NEURONS(16), .APPLY_RELU(1), .OUT_SHIFT(8)) u_fc1 (
        .clk(clk), .rst_n(sys_rst_n), .start_layer(fc1_start_pulse),
        .in_ram_addr(fc1_in_addr), .in_ram_dout(dense_read_data),
        .weight_addr(fc1_w_addr), .weight_dout(fc1_w_dout), .bias_addr(fc1_b_addr), .bias_dout(fc1_b_dout),
        .out_neuron_data(fc1_out_data), .out_neuron_idx(fc1_out_idx), .out_neuron_valid(fc1_out_valid), .layer_done(fc1_done)
    );

    assign fc2_in_data = fc1_to_fc2_buffer[fc2_in_addr[3:0]]; 
    dense_layer #(.IN_NEURONS(16), .OUT_NEURONS(16), .APPLY_RELU(1), .OUT_SHIFT(8)) u_fc2 (
        .clk(clk), .rst_n(sys_rst_n), .start_layer(fc2_start_pulse),
        .in_ram_addr(fc2_in_addr), .in_ram_dout(fc2_in_data),
        .weight_addr(fc2_w_addr), .weight_dout(fc2_w_dout), .bias_addr(fc2_b_addr), .bias_dout(fc2_b_dout),
        .out_neuron_data(fc2_out_data), .out_neuron_idx(fc2_out_idx), .out_neuron_valid(fc2_out_valid), .layer_done(fc2_done)
    );

    assign fc3_in_data = fc2_to_fc3_buffer[fc3_in_addr[3:0]]; 
    dense_layer #(.IN_NEURONS(16), .OUT_NEURONS(10), .APPLY_RELU(0), .OUT_SHIFT(8)) u_fc3 (
        .clk(clk), .rst_n(sys_rst_n), .start_layer(fc3_start_pulse),
        .in_ram_addr(fc3_in_addr), .in_ram_dout(fc3_in_data),
        .weight_addr(fc3_w_addr), .weight_dout(fc3_w_dout), .bias_addr(fc3_b_addr), .bias_dout(fc3_b_dout),
        .out_neuron_data(final_fc3_out), .out_neuron_idx(final_fc3_idx), .out_neuron_valid(final_fc3_valid), .layer_done(cnn_done)
    );

    // =========================================================
    // 5. Control Logic & Buffers
    // =========================================================
    assign pool1_bram_write_data = {pool1_data_out[5], pool1_data_out[4], pool1_data_out[3], pool1_data_out[2], pool1_data_out[1], pool1_data_out[0]};
    assign pool2_bram_write_data = {pool2_data_out[15], pool2_data_out[14], pool2_data_out[13], pool2_data_out[12], pool2_data_out[11], pool2_data_out[10], pool2_data_out[9], pool2_data_out[8], pool2_data_out[7], pool2_data_out[6], pool2_data_out[5], pool2_data_out[4], pool2_data_out[3], pool2_data_out[2], pool2_data_out[1], pool2_data_out[0]};

    always_ff @(posedge clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            pool1_bram_write_addr <= 8'd0; pool1_done <= 1'b0;
            pool2_bram_write_addr <= 5'd0; pool2_done <= 1'b0;
            for(int i=0; i<16; i++) begin fc1_to_fc2_buffer[i] <= 0; fc2_to_fc3_buffer[i] <= 0; end
        end else begin
            if (start_pulse) begin
                pool1_bram_write_addr <= 8'd0; pool1_done <= 1'b0;
                pool2_bram_write_addr <= 5'd0; pool2_done <= 1'b0;
            end else begin
                if (pool1_valid_out) begin 
                    pool1_bram_write_addr <= pool1_bram_write_addr + 1; 
                    if (pool1_bram_write_addr == 8'd195) pool1_done <= 1'b1; 
                end
                if (pool2_valid_out) begin 
                    pool2_bram_write_addr <= pool2_bram_write_addr + 1; 
                    if (pool2_bram_write_addr == 5'd24) pool2_done <= 1'b1; 
                end
            end
            
            if (fc1_out_valid) fc1_to_fc2_buffer[fc1_out_idx[3:0]] <= fc1_out_data;
            if (fc2_out_valid) fc2_to_fc3_buffer[fc2_out_idx[3:0]] <= fc2_out_data;
        end
    end

    // =========================================================
    // 6. LED Controller (ArgMax)
    // =========================================================
    logic signed [15:0] max_score;
    logic [3:0]         predicted_digit;

    always_ff @(posedge clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            max_score <= -16'sd32768; 
            predicted_digit <= 4'd0;
            led <= 4'b0000;           
        end else begin
            if (start_pulse) begin
                max_score <= -16'sd32768;
                predicted_digit <= 4'd0;
            end
            else if (final_fc3_valid) begin
                if (final_fc3_out > max_score) begin
                    max_score <= final_fc3_out;            
                    predicted_digit <= final_fc3_idx[3:0]; 
                end
            end

            if (cnn_done) begin
                led <= predicted_digit; 
            end
        end
    end

    // =========================================================
    // 7. Data Capture for ILA
    // =========================================================
    logic signed [15:0] fc3_all_scores [0:9];

    always_ff @(posedge clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            for(int i=0; i<10; i++) fc3_all_scores[i] <= 16'd0;
        end else begin
            if (start_pulse) begin
                for(int i=0; i<10; i++) fc3_all_scores[i] <= 16'd0;
            end
            else if (final_fc3_valid && (final_fc3_idx < 10)) begin
                fc3_all_scores[final_fc3_idx] <= final_fc3_out;
            end
        end
    end

    // =========================================================
    // =========================================================
    // 8. ILA Instantiation
    // =========================================================
    ila_0 u_ila (
        .clk      (clk),

        .probe0   (start_pulse),           
        .probe1   (cnn_done),              
        .probe2   (led),                   
        .probe3   (fc3_all_scores[0]),     
        .probe4   (fc3_all_scores[1]),     
        .probe5   (fc3_all_scores[2]),     
        .probe6   (fc3_all_scores[3]),     
        .probe7   (fc3_all_scores[4]),     
        .probe8   (fc3_all_scores[5]),     
        .probe9   (fc3_all_scores[6]),     
        .probe10  (fc3_all_scores[7]),     
        .probe11  (fc3_all_scores[8]),     
        .probe12  (fc3_all_scores[9]),      
        .probe13  (image_idx)            // <--- NAYA SIGNAL: Image Counter (0 se 99)
    );

endmodule