`timescale 1ns / 1ps

module line_buffer #(
    parameter IMG_WIDTH = 32 // Conv1 ke liye 32
)(
    input  logic clk,
    input  logic rst_n,
    input  logic valid_in,
    input  logic signed [15:0] pixel_in,
    output logic signed [15:0] window_out [0:4][0:4]
);

    // 4 Shift registers for 5 rows
    logic signed [15:0] row1 [0:IMG_WIDTH-1];
    logic signed [15:0] row2 [0:IMG_WIDTH-1];
    logic signed [15:0] row3 [0:IMG_WIDTH-1];
    logic signed [15:0] row4 [0:IMG_WIDTH-1];

    integer i;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for(i=0; i<IMG_WIDTH; i++) begin
                row1[i] <= '0; row2[i] <= '0; row3[i] <= '0; row4[i] <= '0;
            end
            for(int r=0; r<5; r++) begin
                for(int c=0; c<5; c++) begin
                    window_out[r][c] <= '0;
                end
            end
        end
        else if (valid_in) begin
            // Shift FIFOs
            row1[IMG_WIDTH-1] <= pixel_in;
            for(i=0; i<IMG_WIDTH-1; i++) row1[i] <= row1[i+1];

            row2[IMG_WIDTH-1] <= row1[0];
            for(i=0; i<IMG_WIDTH-1; i++) row2[i] <= row2[i+1];

            row3[IMG_WIDTH-1] <= row2[0];
            for(i=0; i<IMG_WIDTH-1; i++) row3[i] <= row3[i+1];

            row4[IMG_WIDTH-1] <= row3[0];
            for(i=0; i<IMG_WIDTH-1; i++) row4[i] <= row4[i+1];

            // Form 5x5 Window
            window_out[0][4] <= row4[0];
            window_out[1][4] <= row3[0];
            window_out[2][4] <= row2[0];
            window_out[3][4] <= row1[0];
            window_out[4][4] <= pixel_in;

            // Shift window columns
            for(int r=0; r<5; r++) begin
                window_out[r][0] <= window_out[r][1];
                window_out[r][1] <= window_out[r][2];
                window_out[r][2] <= window_out[r][3];
                window_out[r][3] <= window_out[r][4];
            end
        end
    end

endmodule