`timescale 1ns / 1ps

module max_pool_2x2 (
    // 2x2 ki window (Total 4 pixels, Q8.8 format)
    input  logic signed [15:0] window [0:1][0:1], 
    
    // Sabse badi value (Max)
    output logic signed [15:0] max_out              
);

    // Beech ke connections (Stage 1 Winners)
    logic signed [15:0] max_row0;
    logic signed [15:0] max_row1;

    // Purely Combinational Logic (Bina clock ke)
    always_comb begin
        // --------------------------------------------------
        // STAGE 1: Rows ke winners nikalo (Parallel)
        // --------------------------------------------------
        
        // Row 0 me bada kaun?
        if (window[0][0] > window[0][1])
            max_row0 = window[0][0];
        else
            max_row0 = window[0][1];

        // Row 1 me bada kaun?
        if (window[1][0] > window[1][1])
            max_row1 = window[1][0];
        else
            max_row1 = window[1][1];

        // --------------------------------------------------
        // STAGE 2: Final Winner nikalo
        // --------------------------------------------------
        
        // Dono rows ke winners me sabse bada kaun?
        if (max_row0 > max_row1)
            max_out = max_row0;
        else
            max_out = max_row1;
    end

endmodule