`timescale 1ns / 1ps

module mac_engine (
    input  logic               clk,
    input  logic               rst_n,
    input  logic               valid_in,     // Line buffer se signal ki data ready hai
    input  logic signed [15:0] window [0:4][0:4],  // 25 Pixels (Q8.8 format)
    input  logic signed [15:0] weights [0:4][0:4], // 25 Weights (Q8.8 format)
    input  logic signed [15:0] bias,               // 1 Bias (Q8.8 format)
    
    output logic signed [15:0] out_pixel,    // Final output pixel
    output logic               valid_out     // Agle BRAM ko batane ke liye
);

    logic signed [35:0] sum_comb;
    integer r, c;

    always_comb begin
        sum_comb = ( $signed({{20{bias[15]}}, bias}) ) <<< 8; 
        
        for (r = 0; r < 5; r++) begin
            for (c = 0; c < 5; c++) begin
                sum_comb = sum_comb + (window[r][c] * weights[r][c]);
            end
        end
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_pixel <= 16'd0;
            valid_out <= 1'b0;
        end 
        else if (valid_in) begin
            if (sum_comb < 0) begin
                out_pixel <= 16'd0; // ReLU
            end 
            else begin
                // SATURATION FIX
                logic signed [35:0] shifted_val;
                shifted_val = sum_comb >>> 8; 

                if (shifted_val > 36'sd32767) begin
                    out_pixel <= 16'h7FFF; 
                end else begin
                    out_pixel <= shifted_val[15:0];
                end
            end
            valid_out <= 1'b1;
        end 
        else begin
            valid_out <= 1'b0;
        end
    end

endmodule