`timescale 1ns / 1ps

module mac_engine_3d (
    input  logic               clk,
    input  logic               rst_n,
    input  logic               valid_in,     // 3D Line buffer se signal
    
    // 3D Arrays: [Row 0-4][Col 0-4][Channel 0-5]
    input  logic signed [15:0] window_3d [0:4][0:4][0:5],  // 150 Pixels
    input  logic signed [15:0] weights_3d [0:4][0:4][0:5], // 150 Weights
    input  logic signed [15:0] bias,                       // 1 Bias
    
    output logic signed [15:0] out_pixel,
    output logic               valid_out
);

    logic signed [35:0] sum_comb;
    integer r, c, ch;

    always_comb begin
        sum_comb = ( $signed({{20{bias[15]}}, bias}) ) <<< 8; 
        
        for (r = 0; r < 5; r++) begin
            for (c = 0; c < 5; c++) begin
                for (ch = 0; ch < 6; ch++) begin
                    sum_comb = sum_comb + (window_3d[r][c][ch] * weights_3d[r][c][ch]);
                end
            end
        end
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_pixel <= 16'd0;
            valid_out <= 1'b0;
        end 
        else if (valid_in) begin
            if (sum_comb < 0) begin
                out_pixel <= 16'd0; // ReLU
            end 
            else begin
                logic signed [35:0] shifted_val;
                shifted_val = sum_comb >>> 8;

                if (shifted_val > 36'sd32767) begin
                    out_pixel <= 16'h7FFF; 
                end else begin
                    out_pixel <= shifted_val[15:0];
                end
            end
            valid_out <= 1'b1;
        end 
        else begin
            valid_out <= 1'b0;
        end
    end

endmodule