`timescale 1ns / 1ps

module pool2_layer (
    input  logic               clk,
    input  logic               rst_n,
    
    input  logic signed [15:0] conv2_pixel_in,
    input  logic [3:0]         conv2_channel_idx,
    input  logic               conv2_valid_in,

    output logic signed [15:0] pool2_out [0:15], 
    output logic               pool2_valid_out
);

    localparam IMG_WIDTH = 10;

    // --------------------------------------------------------
    // 1. Deserializer (Gatherer) Logic
    // --------------------------------------------------------
    logic signed [15:0] gathered_pixels [0:15];
    logic               gathered_valid;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gathered_valid <= 1'b0;
            for (int i=0; i<16; i++) gathered_pixels[i] <= 16'd0;
        end 
        else begin
            gathered_valid <= 1'b0; 
            
            if (conv2_valid_in) begin
                gathered_pixels[conv2_channel_idx] <= conv2_pixel_in;
                
                if (conv2_channel_idx == 4'd15) begin
                    gathered_valid <= 1'b1;
                end
            end
        end
    end

    // --------------------------------------------------------
    // 2. 2x2 Max Pooling Logic
    // --------------------------------------------------------
    logic [3:0] col_count; 
    logic [3:0] row_count; 

    logic signed [15:0] line_buffer [0:IMG_WIDTH-1][0:15];
    logic signed [15:0] delay_pixel [0:15];
    logic signed [15:0] delay_line_out [0:15];

    logic signed [15:0] window_2x2 [0:15][0:1][0:1]; 
    logic signed [15:0] max_pool_result [0:15];

    genvar i;
    generate
        for (i = 0; i < 16; i++) begin : max_pool_blocks
            assign window_2x2[i][0][0] = delay_line_out[i]; 
            assign window_2x2[i][0][1] = line_buffer[col_count][i]; 
            assign window_2x2[i][1][0] = delay_pixel[i]; 
            assign window_2x2[i][1][1] = gathered_pixels[i];              

            max_pool_2x2 u_max_pool (
                .window(window_2x2[i]),
                .max_out(max_pool_result[i])
            );
        end
    endgenerate

    // --------------------------------------------------------
    // 3. FSM / Data Movement
    // --------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            col_count <= '0; row_count <= '0;
            pool2_valid_out <= 1'b0;
            
            for (int c = 0; c < IMG_WIDTH; c++) begin
                for (int ch = 0; ch < 16; ch++) line_buffer[c][ch] <= '0;
            end
            for (int ch = 0; ch < 16; ch++) begin
                delay_pixel[ch]    <= '0; 
                delay_line_out[ch] <= '0;
                pool2_out[ch]      <= '0;
            end
        end
        else begin
            pool2_valid_out <= 1'b0; 

            if (gathered_valid) begin
                for (int ch = 0; ch < 16; ch++) begin
                    delay_pixel[ch]    <= gathered_pixels[ch];
                    delay_line_out[ch] <= line_buffer[col_count][ch];
                    line_buffer[col_count][ch] <= gathered_pixels[ch];
                end

                if (row_count[0] == 1'b1 && col_count[0] == 1'b1) begin
                    pool2_valid_out <= 1'b1; 
                    for (int ch = 0; ch < 16; ch++) begin
                        pool2_out[ch] <= max_pool_result[ch]; 
                    end
                end

                if (col_count == IMG_WIDTH - 1) begin
                    col_count <= '0;
                    if (row_count == IMG_WIDTH - 1) row_count <= '0; 
                    else row_count <= row_count + 1;
                end else begin
                    col_count <= col_count + 1;
                end
            end
        end
    end
endmodule