`timescale 1ns / 1ps

module line_buffer_3d (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        valid_in,
    // 6 Channels ek sath aa rahe hain (BRAM ki 96-bit line se)
    input  logic signed [15:0] pixel_in [0:5], 
    
    // Output ek 3D Window hai: [Row 0-4][Col 0-4][Channel 0-5]
    output logic signed [15:0] window_3d [0:4][0:4][0:5] 
);

    localparam IMG_WIDTH = 14; // Pool1 ka output size

    // 4 Line Buffers, lekin har location me 6 pixels (channels) hain
    logic signed [15:0] line0 [0:IMG_WIDTH-1][0:5];
    logic signed [15:0] line1 [0:IMG_WIDTH-1][0:5];
    logic signed [15:0] line2 [0:IMG_WIDTH-1][0:5];
    logic signed [15:0] line3 [0:IMG_WIDTH-1][0:5];

    integer i, r, c, ch;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // FIX: Sabhi registers ko loop se zero karna zaroori hai hardware synthesis ke liye
            for (i = 0; i < IMG_WIDTH; i++) begin
                for (ch = 0; ch < 6; ch++) begin
                    line0[i][ch] <= 16'd0;
                    line1[i][ch] <= 16'd0;
                    line2[i][ch] <= 16'd0;
                    line3[i][ch] <= 16'd0;
                end
            end
            for (r = 0; r < 5; r++) begin
                for (c = 0; c < 5; c++) begin
                    for (ch = 0; ch < 6; ch++) begin
                        window_3d[r][c][ch] <= 16'd0;
                    end
                end
            end
        end 
        else if (valid_in) begin
            // --------------------------------------------------
            // 1. Line Buffers me Shift
            // --------------------------------------------------
            for (i = 0; i < IMG_WIDTH-1; i++) begin
                for (ch = 0; ch < 6; ch++) begin
                    line0[i][ch] <= line0[i+1][ch];
                    line1[i][ch] <= line1[i+1][ch];
                    line2[i][ch] <= line2[i+1][ch];
                    line3[i][ch] <= line3[i+1][ch];
                end
            end
            
            // Naya 6-channel pixel insert karo
            for (ch = 0; ch < 6; ch++) begin
                line0[IMG_WIDTH-1][ch] <= pixel_in[ch];
                line1[IMG_WIDTH-1][ch] <= line0[0][ch];
                line2[IMG_WIDTH-1][ch] <= line1[0][ch];
                line3[IMG_WIDTH-1][ch] <= line2[0][ch];
            end

            // --------------------------------------------------
            // 2. 3D Window me Data Daalna
            // --------------------------------------------------
            for (r = 0; r < 5; r++) begin
                for (c = 0; c < 4; c++) begin
                    for (ch = 0; ch < 6; ch++) begin
                        window_3d[r][c][ch] <= window_3d[r][c+1][ch];
                    end
                end
            end

            // Naya column update karo
            for (ch = 0; ch < 6; ch++) begin
                window_3d[0][4][ch] <= line3[0][ch];
                window_3d[1][4][ch] <= line2[0][ch];
                window_3d[2][4][ch] <= line1[0][ch];
                window_3d[3][4][ch] <= line0[0][ch];
                window_3d[4][4][ch] <= pixel_in[ch];
            end
        end
    end
endmodule