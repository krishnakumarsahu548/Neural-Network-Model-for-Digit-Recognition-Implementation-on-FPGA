`timescale 1ns / 1ps

module conv1_layer (
    input  logic clk,
    input  logic rst_n,
    input  logic start_btn,         
    
    output logic [7:0]  weight_addr,
    output logic        weight_en,
    input  logic signed [15:0] weight_dout,
    
    output logic [2:0]  bias_addr,
    output logic        bias_en,
    input  logic signed [15:0] bias_dout,

    output logic [9:0]  img_addr,     
    output logic        img_en,
    input  logic signed [15:0] img_dout,

    output logic signed [15:0] conv_out [0:5], 
    output logic        conv_valid,
    output logic        layer_done
);

    logic signed [15:0] filter_weights [0:5][0:4][0:4]; 
    logic signed [15:0] filter_biases [0:5];

    typedef enum logic [1:0] {
        IDLE = 2'b00,
        LOAD_WEIGHTS = 2'b01,
        PROCESS_IMAGE = 2'b10,
        DONE = 2'b11
    } state_t;

    state_t current_state, next_state;

    logic [10:0] w_count;      
    logic [10:0] b_count;      
    logic [10:0] pixel_count;  
    
    logic [2:0] w_f; 
    logic [2:0] w_r; 
    logic [2:0] w_c;           

    logic signed [15:0] window_2d [0:4][0:4];  
    logic lb_valid_in;
    logic mac_valid [0:5];
    logic [4:0] in_row; 
    logic [4:0] in_col; 
    
    // ---> THE ULTIMATE FIX: 1-Cycle Delayed MAC Trigger <---
    logic mac_trigger;

    line_buffer u_line_buf (.clk(clk), .rst_n(rst_n), .valid_in(lb_valid_in), .pixel_in(img_dout), .window_out(window_2d));

    genvar i;
    generate
        for (i = 0; i < 6; i++) begin : mac_blocks
            // Yahan out_valid_comb ki jagah mac_trigger lagaya gaya hai
            mac_engine u_mac (.clk(clk), .rst_n(rst_n), .valid_in(mac_trigger), .window(window_2d), .weights(filter_weights[i]), .bias(filter_biases[i]), .out_pixel(conv_out[i]), .valid_out(mac_valid[i]));
        end
    endgenerate

    assign conv_valid = mac_valid[0];

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) current_state <= IDLE;
        else current_state <= next_state;
    end

    always_comb begin
        next_state = current_state;
        weight_en = 1'b0; bias_en = 1'b0; img_en = 1'b0; layer_done = 1'b0;

        case (current_state)
            IDLE: if (start_btn) next_state = LOAD_WEIGHTS;
            LOAD_WEIGHTS: begin
                weight_en = 1'b1; bias_en = 1'b1;
                if (w_count >= 11'd151) next_state = PROCESS_IMAGE;
            end
            PROCESS_IMAGE: begin
                img_en = 1'b1; 
                if (pixel_count >= 11'd1025) next_state = DONE;
            end
            DONE: begin
                layer_done = 1'b1;
                next_state = IDLE; 
            end
            default: next_state = IDLE;
        endcase
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            w_count <= '0; b_count <= '0; pixel_count <= '0;
            weight_addr <= '0; bias_addr <= '0; img_addr <= '0;
            lb_valid_in <= 1'b0; in_row <= '0; in_col <= '0; 
            w_f <= '0; w_r <= '0; w_c <= '0;
            mac_trigger <= 1'b0; // Reset the trigger
            for(int k=0; k<6; k++) begin
                filter_biases[k] <= 16'd0;
                for(int m=0; m<5; m++) for(int n=0; n<5; n++) filter_weights[k][m][n] <= 16'd0;
            end
        end 
        else begin
            // ---> Evaluates trigger with 1 cycle delay for PERFECT Sync <---
            mac_trigger <= lb_valid_in && (in_row >= 4) && (in_col >= 4);

            if (current_state == IDLE) begin
                w_count <= '0; b_count <= '0; pixel_count <= '0;
                lb_valid_in <= 1'b0; in_row <= '0; in_col <= '0;
                w_f <= '0; w_r <= '0; w_c <= '0; 
            end
            else if (current_state == LOAD_WEIGHTS) begin
                if (w_count < 150) weight_addr <= w_count[7:0];
                if (b_count < 6)   bias_addr <= b_count[2:0];

                w_count <= w_count + 1;
                b_count <= b_count + 1;

                if (w_count >= 2 && w_count <= 151) begin
                    filter_weights[w_f][w_r][w_c] <= weight_dout;
                    
                    if (w_c == 4) begin
                        w_c <= 0;
                        if (w_r == 4) begin
                            w_r <= 0;
                            w_f <= w_f + 1;
                        end else w_r <= w_r + 1;
                    end else w_c <= w_c + 1;
                end
                
                if (b_count >= 2 && b_count <= 7) begin
                    filter_biases[b_count - 2] <= bias_dout;
                end
            end
            else if (current_state == PROCESS_IMAGE) begin
                if (pixel_count < 1024) begin
                    img_addr <= pixel_count[9:0];
                    pixel_count <= pixel_count + 1;
                end else if (pixel_count == 1024) pixel_count <= pixel_count + 1; 

                if (pixel_count > 0 && pixel_count <= 1024) begin
                    lb_valid_in <= 1'b1; 
                    if (in_col == 5'd31) begin
                        in_col <= 0;
                        in_row <= in_row + 1;
                    end else begin
                        in_col <= in_col + 1;
                    end
                end else lb_valid_in <= 1'b0;
            end
            else lb_valid_in <= 1'b0;
        end
    end
endmodule