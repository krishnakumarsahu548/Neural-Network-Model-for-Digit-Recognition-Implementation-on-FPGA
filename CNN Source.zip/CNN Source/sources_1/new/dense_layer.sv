`timescale 1ns / 1ps

module dense_layer #(
    parameter IN_NEURONS  = 400,
    parameter OUT_NEURONS = 16,
    parameter APPLY_RELU  = 1,
    parameter OUT_SHIFT   = 8   // Shift parameter
)(
    input  logic               clk,
    input  logic               rst_n,
    input  logic               start_layer,
    output logic [15:0]        in_ram_addr,
    input  logic signed [15:0] in_ram_dout,
    output logic [15:0]        weight_addr,
    input  logic signed [15:0] weight_dout,
    output logic [15:0]        bias_addr,
    input  logic signed [15:0] bias_dout,
    output logic signed [15:0] out_neuron_data,
    output logic [15:0]        out_neuron_idx,
    output logic               out_neuron_valid,
    output logic               layer_done
);

    typedef enum logic [2:0] {
        IDLE, FETCH_ADDR, WAIT_BRAM,
        MAC_CALC, FETCH_BIAS, WAIT_BIAS,
        STORE_OUT, DONE
    } state_t;

    state_t current_state;

    logic [15:0]        in_count;
    logic [15:0]        out_count;
    logic signed [31:0] mult_result;

    // 48-bit High-Precision variables
    logic signed [47:0] accumulator;
    logic signed [47:0] final_val;
    logic signed [47:0] bias_aligned;
    logic signed [47:0] acc_with_bias;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_state    <= IDLE;
            in_count         <= 0;
            out_count        <= 0;
            in_ram_addr      <= 0;
            weight_addr      <= 0;
            bias_addr        <= 0;
            accumulator      <= 0;
            out_neuron_data  <= 0;
            out_neuron_idx   <= 0;
            out_neuron_valid <= 0;
            layer_done       <= 0;
        end else begin
            // Default 0 for 1-cycle pulses
            out_neuron_valid <= 0;
            layer_done       <= 0;

            case (current_state)

                IDLE: begin
                    if (start_layer) begin
                        current_state <= FETCH_ADDR;
                        in_count      <= 0;
                        out_count     <= 0;
                        accumulator   <= 0; // Naya image aate hi accumulator 0 (No Drift!)
                    end
                end

                FETCH_ADDR: begin
                    in_ram_addr   <= in_count;
                    weight_addr   <= (out_count * IN_NEURONS) + in_count;
                    current_state <= WAIT_BRAM;
                end

                WAIT_BRAM: begin
                    current_state <= MAC_CALC;
                end

                MAC_CALC: begin
                    logic signed [31:0] op_a, op_b;
                    op_a = in_ram_dout; 
                    op_b = weight_dout; 
                    
                    mult_result = op_a * op_b; 
                    
                    // Q16.16 format me accumulate karna
                    accumulator <= accumulator + mult_result;

                    if (in_count == IN_NEURONS - 1) begin
                        current_state <= FETCH_BIAS;
                        in_count      <= 0;
                    end else begin
                        in_count      <= in_count + 1;
                        current_state <= FETCH_ADDR;
                    end
                end

                FETCH_BIAS: begin
                    bias_addr     <= out_count;
                    current_state <= WAIT_BIAS;
                end

                WAIT_BIAS: begin
                    current_state <= STORE_OUT;
                end

                STORE_OUT: begin
                    // HIGH-PRECISION LOGIC
                    bias_aligned = $signed({{32{bias_dout[15]}}, bias_dout}) <<< OUT_SHIFT;
                    acc_with_bias = accumulator + bias_aligned;
                    final_val = acc_with_bias >>> OUT_SHIFT;
                    
                    // ReLU & Saturation Clamping
                    if (APPLY_RELU == 1 && final_val < 0) begin
                        out_neuron_data <= 16'd0;
                    end else if (final_val > 48'sh7FFF) begin
                        out_neuron_data <= 16'h7FFF;
                    end else if (final_val < -48'sh8000) begin
                        out_neuron_data <= 16'h8000;
                    end else begin
                        out_neuron_data <= final_val[15:0];
                    end

                    out_neuron_idx   <= out_count;
                    out_neuron_valid <= 1'b1;

                    if (out_count == OUT_NEURONS - 1) begin
                        current_state <= DONE;
                    end else begin
                        out_count     <= out_count + 1;
                        accumulator   <= 0; // Agle neuron ke liye purana kachra saaf!
                        current_state <= FETCH_ADDR;
                    end
                end

                DONE: begin
                    layer_done <= 1'b1;
                    current_state <= IDLE; // <-- BUG FIX: Wapas IDLE me jaana zaroori tha!
                end

                default: current_state <= IDLE;
            endcase
        end
    end
endmodule